# Pork & Garlic Ice Cream — Year 2 Winter Decision Tool

A responsive decision model for comparing winter strategies in the classroom business simulation. All inputs are editable, stored in the browser, and initially populated with clearly marked demo data.

## Run locally

Requirements: Node.js 22.13 or newer.

```bash
npm install
npm run dev
```

Open the local URL shown in the terminal. Run the automated accounting checks with:

```bash
npm test
```

Create a production build with `npm run build`.

## Calculation rules

- Modeled production is capped by planned production, available milk, and installed machine capacity.
- Actual sales are capped by feasible production. Downside scenarios apply 100%, 80%, or 60% to the expected allocation before that cap.
- Milk costs are charged exactly once for every ton purchased. Unused milk and unsold ice cream spoil without a second spoilage charge.
- Sales across premises are allocated in proportion to planned production. Transport is charged only on units actually sold.
- Every owned machine incurs maintenance. Depreciation applies while remaining useful life is positive. New machines incur maintenance and depreciation in the purchase season.
- Gross profit is revenue less milk, maintenance, and depreciation. Bonus is charged only when gross profit is positive.
- Tax losses offset positive profit before tax. New losses increase the pool. Taxable profit cannot be negative.
- Machine purchases, loan receipts, and principal repayments affect cash but not profit. Only interest is a profit-and-loss expense.
- Loan proceeds are assumed available before advance payments. Machines, milk, and market investment are paid in advance; operating payments and sales receipts occur at season end.

## Assumptions and limitations

- The seeded values are Year 1 estimates and are **not confirmed Year 2 rules**.
- The 410,000-unit winter forecast is a total-market reference, not guaranteed company sales. A range of 328,000–492,000 shows ±20% uncertainty.
- The trainer controls sales allocations; the tool compares scenarios and does not predict an allocation.
- A strategy rents any premise with planned production or installed machines.
- Existing scheduled loan repayments are treated as season-end principal payments. New-loan interest and repayment are editable per strategy.
- Browser storage is device-local. Resetting site data or choosing “Reset to demo” removes saved inputs.

## Built-in verification

The automated tests prove the supplied Year 1 example produces:

- Net loss: **Sh 3,560**
- Closing cash: **Sh 71,940**

The “Verify Year 1” screen also lets a team compare a calculated season with its classroom results.

## Deploy

### GitHub

Create an empty GitHub repository, add it as the remote, and push the main branch:

```bash
git remote add origin https://github.com/YOUR-ACCOUNT/YOUR-REPOSITORY.git
git push -u origin main
```

### Vercel

Import the GitHub repository in Vercel. The project uses the standard Next.js settings; no environment variables or database are required. Keep the default build command and deploy.
