export type Premise = { id: string; name: string; slots: number; transport: number; rent: number };
export type MachineType = { id: string; name: string; capacity: number; purchase: number; maintenance: number; depreciation: number };
export type OwnedMachine = { id: string; name: string; typeId: string; purchasePrice: number; remainingLife: number; capacity: number; maintenance: number };
export type Loan = { id: string; name: string; principal: number; interestRate: number; remainingRepayments: number; repaymentAmount: number };
export type ProductionRow = { premiseId: string; units: number; newMachines: Record<string, number> };
export type Strategy = {
  id: string; name: string; milkTons: number; salesRequest: number; expectedSales: number;
  marketInvestment: number; production: ProductionRow[]; machineUse: Record<string, string>;
  newBorrowing: number; newLoanRate: number; newLoanRepayment: number; notes: string;
};
export type Assumptions = {
  sellingPrice: number; milkPrice: number; milkYield: number; minimumMilk: number;
  salaries: number; minimumMarket: number; depreciationLife: number; taxRate: number;
  bonusRate: number; defaultLoanRate: number; premises: Premise[]; machineTypes: MachineType[];
};
export type StartingPosition = { cash: number; annualProfit: number; taxLossPool: number; machines: OwnedMachine[]; loans: Loan[]; demo: boolean };

export const money = (value: number) => `Sh ${Math.round(value).toLocaleString("en-US")}`;
const sum = (values: number[]) => values.reduce((a, b) => a + (Number.isFinite(b) ? b : 0), 0);
const nonNegative = (value: number) => Math.max(0, Number.isFinite(value) ? value : 0);

export function calculateStrategy(start: StartingPosition, a: Assumptions, s: Strategy, salesFactor = 1) {
  const machineMap = Object.fromEntries(a.machineTypes.map((m) => [m.id, m]));
  const premiseMap = Object.fromEntries(a.premises.map((p) => [p.id, p]));
  const plannedProduction = sum(s.production.map((r) => nonNegative(r.units)));
  const milkTons = nonNegative(s.milkTons);
  const milkCapacity = milkTons * nonNegative(a.milkYield);
  const existingCapacityByPremise: Record<string, number> = {};
  const existingCountByPremise: Record<string, number> = {};
  for (const m of start.machines) {
    const place = s.machineUse[m.id];
    if (place && place !== "idle") {
      if (m.remainingLife > 0) existingCapacityByPremise[place] = (existingCapacityByPremise[place] || 0) + nonNegative(m.capacity);
      existingCountByPremise[place] = (existingCountByPremise[place] || 0) + 1;
    }
  }
  let purchaseCost = 0;
  let newMaintenance = 0;
  let newDepreciation = 0;
  let totalInstalledCapacity = sum(Object.values(existingCapacityByPremise));
  const machinesByPremise: Record<string, number> = { ...existingCountByPremise };
  for (const row of s.production) {
    for (const [typeId, qtyRaw] of Object.entries(row.newMachines || {})) {
      const qty = Math.max(0, qtyRaw || 0);
      const type = machineMap[typeId];
      if (!type) continue;
      totalInstalledCapacity += type.capacity * qty;
      machinesByPremise[row.premiseId] = (machinesByPremise[row.premiseId] || 0) + qty;
      purchaseCost += type.purchase * qty;
      newMaintenance += type.maintenance * qty;
      newDepreciation += type.depreciation * qty;
    }
  }
  const feasibleProduction = Math.max(0, Math.min(plannedProduction, milkCapacity, totalInstalledCapacity));
  const actualSales = Math.max(0, Math.min(nonNegative(s.expectedSales) * nonNegative(salesFactor), feasibleProduction));
  const revenue = actualSales * nonNegative(a.sellingPrice);
  const milkCost = milkTons * nonNegative(a.milkPrice);
  const maintenance = sum(start.machines.map((m) => nonNegative(m.maintenance))) + newMaintenance;
  const depreciationLife = Math.max(1, nonNegative(a.depreciationLife));
  const depreciation = sum(start.machines.filter((m) => m.remainingLife > 0).map((m) => nonNegative(m.purchasePrice) / depreciationLife)) + newDepreciation;
  const grossProfit = revenue - milkCost - maintenance - depreciation;
  const productionDenominator = plannedProduction || 1;
  const transport = sum(s.production.map((row) => {
    const premise = premiseMap[row.premiseId];
    return nonNegative(premise?.transport || 0) * actualSales * (nonNegative(row.units) / productionDenominator);
  }));
  const rentedIds = new Set([
    ...s.production.filter((r) => nonNegative(r.units) > 0 || (machinesByPremise[r.premiseId] || 0) > 0).map((r) => r.premiseId),
    ...Object.values(s.machineUse).filter((id) => id && id !== "idle"),
  ]);
  const rent = sum([...rentedIds].map((id) => nonNegative(premiseMap[id]?.rent || 0)));
  const bonus = Math.max(0, grossProfit) * a.bonusRate;
  const existingInterest = sum(start.loans.filter((l) => l.remainingRepayments > 0).map((l) => nonNegative(l.principal) * nonNegative(l.interestRate)));
  const newBorrowing = nonNegative(s.newBorrowing);
  const marketInvestment = nonNegative(s.marketInvestment);
  const interest = existingInterest + newBorrowing * nonNegative(s.newLoanRate);
  const profitBeforeTax = grossProfit - transport - marketInvestment - bonus - nonNegative(a.salaries) - rent - interest;
  const availableLossPool = nonNegative(start.taxLossPool);
  const taxLossUsed = profitBeforeTax > 0 ? Math.min(availableLossPool, profitBeforeTax) : 0;
  const taxableProfit = Math.max(0, profitBeforeTax - taxLossUsed);
  const tax = taxableProfit * nonNegative(a.taxRate);
  const netProfit = profitBeforeTax - tax;
  const updatedTaxLossPool = profitBeforeTax < 0 ? availableLossPool + Math.abs(profitBeforeTax) : availableLossPool - taxLossUsed;
  const principalRepayments = sum(start.loans.filter((l) => l.remainingRepayments > 0).map((l) => Math.min(nonNegative(l.principal), nonNegative(l.repaymentAmount)))) + Math.min(newBorrowing, nonNegative(s.newLoanRepayment));
  const advancePayments = purchaseCost + milkCost + marketInvestment;
  const cashAfterAdvances = start.cash + newBorrowing - advancePayments;
  const endPayments = rent + maintenance + transport + nonNegative(a.salaries) + bonus + principalRepayments + interest + tax;
  const closingCash = cashAfterAdvances + revenue - endPayments;
  const warnings: string[] = [];
  if (start.demo) warnings.push("Replace the demo Year 1 figures with your team’s actual results.");
  if (plannedProduction > totalInstalledCapacity) warnings.push(`Reduce production by ${Math.ceil(plannedProduction - totalInstalledCapacity).toLocaleString()} units or install more machine capacity.`);
  if (plannedProduction > milkCapacity) warnings.push(`Buy enough milk or reduce production by ${Math.ceil(plannedProduction - milkCapacity).toLocaleString()} units.`);
  if (s.expectedSales > feasibleProduction) warnings.push("Lower expected actual sales or increase feasible production; modeled sales are capped at feasible production.");
  if (s.salesRequest > plannedProduction) warnings.push("Lower the sales request or increase feasible production.");
  if (s.milkTons < a.minimumMilk) warnings.push(`Buy at least ${a.minimumMilk} ton of milk.`);
  if (s.marketInvestment < a.minimumMarket) warnings.push(`Increase market investment to at least ${money(a.minimumMarket)}.`);
  for (const [id, count] of Object.entries(machinesByPremise)) {
    if (count > (premiseMap[id]?.slots || 0)) warnings.push(`${premiseMap[id]?.name || "A premise"} has ${count} machines but only ${premiseMap[id]?.slots || 0} slot(s). Reassign machines.`);
  }
  for (const m of start.machines) if (m.remainingLife <= 0 && s.machineUse[m.id] && s.machineUse[m.id] !== "idle") warnings.push(`${m.name} is past its useful life. Leave it idle or replace it.`);
  if (cashAfterAdvances < 0) warnings.push(`Advance payments exceed available cash by ${money(Math.abs(cashAfterAdvances))}. Add borrowing or reduce advance spending.`);
  if (closingCash < 0) warnings.push(`Closing cash is negative by ${money(Math.abs(closingCash))}. Improve sales, cut costs, or arrange financing.`);
  for (const row of s.production) if (row.units > 0 && !premiseMap[row.premiseId]) warnings.push("Choose a valid premise for every production row.");
  warnings.push("Confirm all Year 2 assumptions with the trainer before the final decision.");
  return {
    plannedProduction, feasibleProduction, milkCapacity, totalInstalledCapacity, actualSales,
    unusedMilk: Math.max(0, milkCapacity - feasibleProduction), unsold: Math.max(0, feasibleProduction - actualSales),
    utilization: totalInstalledCapacity ? feasibleProduction / totalInstalledCapacity : 0,
    revenue, milkCost, maintenance, depreciation, machineCosts: maintenance + depreciation,
    grossProfit, transport, rent, bonus, interest, profitBeforeTax, taxLossUsed, taxableProfit,
    tax, netProfit, updatedTaxLossPool, purchaseCost, principalRepayments, advancePayments,
    cashAfterAdvances, endPayments, closingCash, warnings,
  };
}

export function calculateYearOneDemo() {
  const revenue = 40_000 * 2;
  const milkCost = 2 * 20_000;
  const maintenance = 1_300;
  const depreciation = 3_500;
  const grossProfit = revenue - milkCost - maintenance - depreciation;
  const bonus = grossProfit * 0.05;
  const profitBeforeTax = grossProfit - 16_000 - 1_000 - bonus - 10_000 - 10_000;
  const closingCash = 100_000 - 28_000 - milkCost - 1_000 + revenue - maintenance - 16_000 - 10_000 - bonus - 10_000;
  return { revenue, maintenance, depreciation, bonus, profitBeforeTax, netProfit: profitBeforeTax, closingCash };
}
