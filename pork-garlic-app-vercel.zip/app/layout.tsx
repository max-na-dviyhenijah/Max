import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Pork & Garlic Ice Cream — Year 2 Winter Decision Tool",
  description: "Compare winter production, finance, and downside-sales strategies for the classroom business simulation.",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className="antialiased">{children}</body>
    </html>
  );
}
