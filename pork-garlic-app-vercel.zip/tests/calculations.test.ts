import test from "node:test";
import assert from "node:assert/strict";
import type { Assumptions, StartingPosition, Strategy } from "../lib/calculations.ts";
import { calculateStrategy, calculateYearOneDemo } from "../lib/calculations.ts";

const assumptions: Assumptions = {
  sellingPrice: 2, milkPrice: 20000, milkYield: 20000, minimumMilk: 1,
  salaries: 10000, minimumMarket: 1000, depreciationLife: 8, taxRate: .1,
  bonusRate: .05, defaultLoanRate: .1,
  premises: [
    { id: "A", name: "Premise A", slots: 2, transport: .3, rent: 12000 },
    { id: "B", name: "Premise B", slots: 1, transport: .4, rent: 10000 },
  ],
  machineTypes: [{ id: "T5", name: "Type 5", capacity: 45000, purchase: 28000, maintenance: 1300, depreciation: 3500 }],
};
const starting: StartingPosition = {
  cash: 100000, annualProfit: 0, taxLossPool: 0, demo: false,
  machines: [{ id: "m1", name: "Owned", typeId: "T5", purchasePrice: 40000, remainingLife: 4, capacity: 45000, maintenance: 1300 }],
  loans: [],
};
const plan: Strategy = {
  id: "s1", name: "Plan", milkTons: 2, salesRequest: 40000, expectedSales: 40000,
  marketInvestment: 1000, production: [{ premiseId: "A", units: 40000, newMachines: {} }],
  machineUse: { m1: "A" }, newBorrowing: 0, newLoanRate: .1, newLoanRepayment: 0, notes: "",
};

test("built-in Year 1 example produces the expected net loss", () => {
  assert.equal(calculateYearOneDemo().netProfit, -3560);
});

test("built-in Year 1 example produces the expected closing cash", () => {
  assert.equal(calculateYearOneDemo().closingCash, 71940);
});

test("owned-machine depreciation follows its actual purchase price", () => {
  assert.equal(calculateStrategy(starting, assumptions, plan).depreciation, 5000);
});

test("an existing machine is counted once across duplicate premise rows", () => {
  const duplicateRows = { ...plan, production: [{ premiseId: "A", units: 20000, newMachines: {} }, { premiseId: "A", units: 20000, newMachines: {} }] };
  assert.equal(calculateStrategy(starting, assumptions, duplicateRows).totalInstalledCapacity, 45000);
});

test("expired machines incur maintenance but provide no capacity or depreciation", () => {
  const expired = { ...starting, machines: [{ ...starting.machines[0], remainingLife: 0 }] };
  const result = calculateStrategy(expired, assumptions, plan);
  assert.equal(result.totalInstalledCapacity, 0);
  assert.equal(result.maintenance, 1300);
  assert.equal(result.depreciation, 0);
  assert.equal(result.feasibleProduction, 0);
});

test("unused milk is charged once and does not create a second spoilage expense", () => {
  const excessMilk = { ...plan, milkTons: 3 };
  const result = calculateStrategy(starting, assumptions, excessMilk);
  assert.equal(result.milkCost, 60000);
  assert.equal(result.unusedMilk, 20000);
  assert.equal(result.grossProfit, 80000 - 60000 - 1300 - 5000);
});

test("sales are capped by feasible production and produce a clear warning", () => {
  const overAllocated = { ...plan, expectedSales: 60000 };
  const result = calculateStrategy(starting, assumptions, overAllocated);
  assert.equal(result.actualSales, 40000);
  assert.ok(result.warnings.some((warning) => warning.includes("modeled sales are capped")));
});

test("tax losses offset profit before game tax is applied", () => {
  const withLossPool = { ...starting, taxLossPool: 10000 };
  const profitable = { ...plan, milkTons: 1, production: [{ premiseId: "A", units: 20000, newMachines: {} }], salesRequest: 20000, expectedSales: 20000, marketInvestment: 1000 };
  const taxAssumptions = { ...assumptions, salaries: 0, bonusRate: 0, premises: [{ ...assumptions.premises[0], rent: 0, transport: 0 }] };
  const result = calculateStrategy(withLossPool, taxAssumptions, profitable);
  assert.equal(result.profitBeforeTax, 12700);
  assert.equal(result.taxLossUsed, 10000);
  assert.equal(result.taxableProfit, 2700);
  assert.equal(result.tax, 270);
  assert.equal(result.updatedTaxLossPool, 0);
});
